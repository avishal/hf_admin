export const environment = {
  production: true,
  // defaultauth: 'fackbackend',
  defaultauth: 'laravelbackend',
  firebaseConfig: {
    apiKey: '',
    authDomain: '',
    databaseURL: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: '',
    measurementId: ''
  },


  // "api_base_url": "http://ec2-13-235-33-88.ap-south-1.compute.amazonaws.com/homefitindia/public/index.php"
  "api_base_url": "http://ec2-13-232-21-118.ap-south-1.compute.amazonaws.com/homefitindia/public/index.php"
};
