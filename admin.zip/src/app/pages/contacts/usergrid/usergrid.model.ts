export interface Usergrid {
    id: number;
    image?: string;
    name: string;
    text: string;
    projects: string[];
    email: string;
}
